/**
 * Created by BALASUBRAMANIAM on 14-04-2016.
 */
$(document).ready(function(){

    $("#login").click(function()
    {
        console.log($("#lmobile").val());
        console.log($("#password").val());
        if(window.localStorage.getItem("password")!=undefined)
        {
            if(window.localStorage.getItem("mobile")!=undefined)
            {
                console.log(window.localStorage.getItem("mobile"));
                console.log(window.localStorage.getItem("password"));
                if($("#lmobile").val()==window.localStorage.getItem("mobile"))
                {
                    if($("#password").val()==window.localStorage.getItem("password"))
                    {
                        if (Notification.permission !== "granted") {

                            Notification.requestPermission();

                        }
                        else {

                            var notification = new Notification('facebook notification', {
                                icon: 'images/facebook.jpg',
                                body: "Hey there! Login Success!"
                            });

                            notification.onclick = function () {
                                notification.close();
                                window.open("Profile.html");
                            };

                        }
                    }
                }

            }
        }

    })







    $("#reg").submit(function()
    {
        console.log($("#firstname").val());
        console.log($("#surname").val());
        if($("#mobile").val()==$("#confirm").val()) {
            console.log($("#mobile").val());
            window.localStorage.setItem("mobile",$("#mobile").val());
        }
            console.log($("#pwd").val());
        window.localStorage.setItem("password",$("#pwd").val());
        $(":radio:checked").each(
            function() {
                console.log( $(this).val() );
                window.localStorage.setItem("gender",$(this).val());
            }
        );
        console.log($("#birthday").val());
        window.localStorage.setItem("birthday",$("#birthday").val());
        window.localStorage.setItem("firstname",$("#firstname").val());
        window.localStorage.setItem("surname",$("#surname").val());

        fileref=document.getElementById("profilePhoto");
        //console.log(fileref.files[0]);
        filetype=/image.*/;

        if(fileref.files[0].type.match(filetype))
        {
           reader = new FileReader();
            reader.readAsDataURL(fileref.files[0]);
            reader.onload = function () {

                window.localStorage.setItem("polarisPhoto",reader.result);
                console.log("file stored");
            };

        }
        if (!Notification) {
            alert('Desktop notifications not available in your browser. Try Chromium.');
            return;
        }

        if (Notification.permission !== "granted") {

            Notification.requestPermission();

        }
        else {

            var notification = new Notification('facebook notification', {
                icon: 'images/facebook.jpg',
                body: "Hey there! You've been registered!"
            });

            notification.onclick = function () {
                notification.close();
                window.open("http://www.shimply.com");
            };

        }


        //console.log($("#firstname").val());
        //console.log($("#firstname").val());
    });




});

