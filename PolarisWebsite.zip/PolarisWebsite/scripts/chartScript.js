/**
 * Created by BALASUBRAMANIAM on 15-04-2016.
 */
window.onload=init;
function init()
{
    var canvas = document.getElementById("bargraph");

    var barcontext = canvas.getContext('2d');

    barcontext.beginPath();
    barcontext.moveTo(200, 400);
    barcontext.lineTo(800, 400);
    barcontext.moveTo(200, 400);
    barcontext.lineTo(200, 100);
    barcontext.lineWidth="5";
    barcontext.strokeStyle="navy";
    barcontext.closePath();
    barcontext.stroke();

    array = new Array(100,45,25,95,55,45,80);
    k=0;
    maxbarh=400;
    barcontext.font = 'italic 40pt Calibri';
    for(i=220;i<800;i=i+70)
    {
        barcontext.beginPath();
        barcontext.rect(i,(maxbarh-array[k]),50,array[k]);
        if(array[k]>60)
            barcontext.fillStyle="green";
        else
            barcontext.fillStyle="red";
        barcontext.fill();
        barcontext.lineWidth="7"
        barcontext.strokeStyle='black';
        barcontext.fillText(array[k], i,(maxbarh-array[k]));
        barcontext.closePath();
        barcontext.stroke();
        k=k+1;
        if(k==7)
            break;
    }


    barcontext.beginPath();
    barcontext.moveTo(250,400);
//barcontext.rotate(Math.PI/2);
    barcontext.fillText("Trainees", 350, 450);

    barcontext.closePath();
    barcontext.stroke();

    barcontext.beginPath();
//barcontext.moveTo(200,400);
    barcontext.rotate(Math.PI/2);

    barcontext.fillText("Score", 250,-100);

    barcontext.closePath();
    barcontext.stroke();
    array = new Array("red","blue","brown","yellow","green");
    canvas = document.getElementById("ring");
    context= canvas.getContext('2d');
    xpos=150;
    ypos=200;
    for(i=0;i<5;i++) {
        context.beginPath();
        context.arc(xpos, ypos, 75, 0, 2 * Math.PI, false);
        context.lineWidth = "4";
       // context.fillStyle="red";
        //context.fill();
        context.strokeStyle = array[i];
        context.closePath();
        context.stroke();
        xpos=xpos+75;
        if(i==2)
        {
            xpos=225;
            ypos=275;
        }

    }



}