/**
 * Created by BALASUBRAMANIAM on 14-04-2016.
 */

$(document).ready(function(){
    //$('footer').cycle('fade');

    $('footer').cycle({
        fx:    'zoom',
        sync:  false,
        delay: -2000
    });
});

